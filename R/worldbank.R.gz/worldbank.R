# Leo Lahti, 2010-
# Licence: GNU GPL >=2

# Examples on getting and analyzing world bank data

# Data details:                                        
# http://data.worldbank.org/data-catalog

###########################################

# World Development Indicators

# See also getURLContent() in RCurl package
# can work on the data in memory without storing on disk
#tmp <- url(description = "http://databank.worldbank.org/databank/download/WDIandGDF_csv.zip", open = "r", blocking = TRUE, encoding = getOption("encoding"))
#http://databank.worldbank.org/databank/download/WDIandGDF_csv.zip

my.url  <- "http://databank.worldbank.org/databank/download/WDIandGDF_csv.zip"
my.path <- "/share/work/lmlahti/tmp/"
my.file <- paste(my.path,"wdi.zip", sep = "")
tmpdir  <- paste(my.path, "tmp", gsub(":","-",gsub(" ","",as.character(date()))), sep = "")
# Download files
download.file(my.url, my.file, mode = "r+");
unzip(my.file, exdir = tmpdir)
#list the available files
li <- list.files(tmpdir, full.names = TRUE)
# read table
# consider setting colClasses (as that stackoverflow answer points out
# Later define the classes here already
# also change into data.frame system asap
tablist <- lapply(li, function(l){read.csv(l, colClasses = "character")})

ri <- which(tablist[[2]][,2] == "Forest area (sq. km)" & tablist[[2]][,4] == "Denmark")
yr <- as.numeric(gsub("X","",colnames(tablist[[2]])[5:54]))
plot(yr,as.numeric(tablist[[2]][ri,5:54]))

########################################################################

# World Governance Indicators                                        
# http://info.worldbank.org/governance/wgi/index.asp
# Related research papers etc.:
# http://info.worldbank.org/governance/wgi/resources.htm
# Dataset
http://info.worldbank.org/governance/wgi/pdf/wgidataset.xls
